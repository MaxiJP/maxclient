package dev.maxprime.maxclient.event.impl;

import dev.maxprime.maxclient.event.Event;

public class ClientTick extends Event {
	
	
	
}
