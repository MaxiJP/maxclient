package dev.maxprime.maxclient.mod;

public enum Category {
		
	HUD,
	WORLD,
	MISC,
	COSMETIC;
	
}
